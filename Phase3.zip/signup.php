<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="signup.css" type="text/css" rel="Stylesheet" />
	<title>Sign Up</title>
</head>

<body>
	
	<h1 style="text-align: center;">Sign Up</h1>
	<p>Please fill this form to create an account.</p>

	<form action="signup.inc.php" method="post">
		<label><b>Full Name</b></label>
		<input type="text" name="name" placeholder="Full name..">
		<br>

		<label><b>Email</b></label>

		<input type="text" name="email" placeholder="Email..">
		<br>

		<label><b>Username</b></label>
		<input type="text" name="uid" placeholder="Username..">
		<br>

		<label><b>Role</b></label>
		<input type="text" name="role" placeholder="Role..">

		<label><b>Password</b></label>
		<input type="password" name="pwd" placeholder="Password..">
		<br>

		<label><b>Repeat Password</b></label>
		<input type="password" name="pwdrepeat" placeholder="Repeat password..">
		<br>

		<label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>

    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>

		<button type="submit" class="signupbtn"name="submit">Sign Up</button>

		
	</form>
	<?php

		if(isset($_GET["error"])){
			if($_GET["error"] == "emptyinput"){
				echo "<p>Fill in all fields ! </p>";
			}

			else if($_GET["error"] == "invalidUid"){
				echo "<p>Choose a proper username!</p>";
			}

			else if($_GET["error"] == "invalidEmail"){
				echo "<p>Choose a proper email!</p>";
			}
			else if($_GET["error"] == "passworddontmatch"){
				echo "<p>Choose a proper username!</p>";
			}
			else if($_GET["error"] == "stmtfailed"){
				echo "<p>Something went wrong, try again!</p>";
			}
			else if($_GET["error"] == "usernametaken"){
				echo "<p>Username Already Taken !</p>";
			}
			else if($_GET["error"] == "none"){
				echo "<p>You have signed up !</p>";
			}
		}
	?>


</body>

</html>
