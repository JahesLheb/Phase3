<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "platinumbrokerage";
$connection = mysqli_connect ($dbhost, $dbuser, $dbpass, $dbname); //Connects to database

//Checks for errors
if (mysqli_connect_errno())
{
    die ("Database connection failed: ".mysqli_connect_error()."(".mysqli_connect_errno().") ");
}
else
{
  debug_to_console("Connected to database");
}

//Used to log to console
function debug_to_console($data) {
  $output = $data;
  if (is_array($output))
      $output = implode(',', $output);

  echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}

//Closes connection
$connection->close();
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Required for Bootstrap5 -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="style.css">

    <script>
      function displayResults()
      {
        // Get search field values
        var input1 = document.getElementById("inputLocation");
        var value1 = input1.value;

        var input2 = document.getElementById("inputName");
        var value2 = input2.value;

        var input3 = document.getElementById("inputSpecialty");
        var value3 = input3.value;

        var input4 = document.getElementById("inputLanguage");
        var value4 = input4.value;

        var input5 = document.getElementById("inputOffice");
        var value5 = input5.value;
        
        // Check if function retreives data
        console.log(value1);
        console.log(value2);
        console.log(value3);
        console.log(value4);
        console.log(value5);

        // If no options were selected
        if (value1 == value2 && value2 == value3 && value3 == value5 && value5 == "" && value4 == "Choose..." )
        {
          document.getElementById("results").innerHTML = "";
          console.log("No search options selected.")
          return;
        }
        // Get search results
        else
        {
          var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function()
          {
            if (this.readyState == 4 && this.status == 200)
            {
              document.getElementById("results").innerHTML = this.responseText;
            }
          };
          xmlhttp.open("GET","getResults.php?location=" + value1 + "&name=" + value2 + "&specialty=" + value3 + "&language=" + value4 + "&office=" + value5, true);
          xmlhttp.send();
        }
      }
    </script>
</head>

<body>
  <!-- Bootstrap Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Navbar</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Link</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#">Action</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
          </li>
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </nav>

  <!-- Banner -->
  <div id="bannerPic" class="container-fluid p-5 bg-primary text-white text-center">
    <div id="bannerTitle">FIND YOUR AGENT</div>
  </div>

  <!-- Search Fields -->
  <div class="container-fluid" id="searchForm">
    <form method="get" class="row g-3" id="form"> <!--dont need't get and csrf, form is not used to get input-->
      <div class="form-group col-md-6">
        <label for="inputLocation">Location</label>
        <input type="text" class="form-control" id="inputLocation" placeholder="Province/Territory">
      </div>

      <div class="form-group col-md-6">
        <label for="inputName">Name</label>
        <input type="text" class="form-control" id="inputName" placeholder="Realtor's Name">
      </div>

      <div class="form-group col-md-6">
        <label for="inputSpeciality">Specialties</label>
        <input type="text" class="form-control" id="inputSpecialty" placeholder="Buying, Selling, or Leasing">
      </div>

      <div class="form-group col-md-6">
        <label for="inputLanguage">Language</label>
        <select id="inputLanguage" class="form-control">
          <option selected>Choose...</option>
          <option>English</option>
          <option>Croatian</option>
          <option>Dutch</option>
          <option>Japanese</option>
          <option>Spanish</option>
        </select>
      </div>

      <div class="form-group col-md-12">
        <label for="inputOffice">Branch Name</label>
        <input type="text" class="form-control" id="inputOffice" placeholder="Building Name">
      </div>

      <button type="button" id="submit" class="btn btn-primary" onclick="displayResults()">Search</button>
    </form>
  </div>

  <div id="results"></div>
</body>
</html>
