<?php
    include_once 'connect.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Platinum</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", Arial, Helvetica, sans-serif}
            .mySlides {display: none}
        </style>
    </head>
    <body class="w3-content w3-border-left w3-border-right">
        
        
    <?php
        $sql = "SELECT * FROM property;";
        $result = mysqli_query($conn, $sql); 
        $resultCheck = mysqli_num_rows($result);
        if($resultCheck > 0){
            $baths = array();
            $beds = array();
            $sqrFt = array();
            $price = array();
            $city = array();
            $prov = array();
            $count = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                $baths[$count] = $row['Bathrooms'];
                $beds[$count] = $row['Bedrooms'];
                $sqrFt[$count] = $row['Sqr_Ft'];
                $price[$count] = $row['Price'];
                $city[$count] = $row['City'];
                $prov[$count] = $row['Province'];
                $count++;
            }
        }
        $sql1 = "SELECT * FROM listing;";
        $result1 = mysqli_query($conn, $sql1);
        $resultCheck = mysqli_num_rows($result1);
        if($resultCheck > 0){
            $count1 = 0;
            while($row1 = mysqli_fetch_assoc($result1)) {
                $count1 = intval($row1['Property_ID']);
                $stat[$count1-1] = $row1['Status'];
            }
        }
        $row1 = mysqli_fetch_assoc($result1);
    ?>

    


    <!-- Sidebar/menu -->
    <nav class="w3-sidebar w3-light-grey w3-collapse w3-top" style="z-index:3;width:260px" id="mySidebar">
    <div class="w3-container w3-display-container w3-padding-16">
        <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-transparent w3-display-topright"></i>
        <h3>Book a Showing with one of our Platinum Brokers</h3>
        <hr>
        <form action="/action_page.php" target="_blank">
        <p><label><i class="fa fa-calendar-check-o"></i> Showing Date</label></p>
        <input class="w3-input w3-border" type="text" placeholder="DD MM YYYY" name="" required>                   
        <p><label><i class="fa fa-phone"></i> Phone Number</label></p>
        <input class="w3-input w3-border" type="number" placeholder="+1 (123)-456-7890" name="number">              
        <p><label><i class="fa fa-user"></i> Full Name </label></p>
        <input class="w3-input w3-border" type="text" placeholder= "John Doe" name="">
        <p><button class="w3-button w3-block w3-green w3-left-align" type="submit"><i class="fa fa-search w3-margin-right"></i> Send Request</button></p>
        </form>
    </div>
    <div class="w3-bar-block">
        <a href="#apartment" class="w3-bar-item w3-button w3-padding-16"><i class="fa fa-instagram"></i> @platinumBrokerage</a>
        <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-16"><i class="fa fa-twitter"></i> @platinumBrokerage</a>
        <a href="#contact" class="w3-bar-item w3-button w3-padding-16"><i class="fa fa-envelope"></i> conn@platinumBrokers.com</a>
    </div>
    </nav>
    
    

    <!-- !PAGE CONTENT! -->
    <div class="w3-main w3-white" style="margin-left:260px">

    <!-- listing #1 -->
    <div class="w3-container" id="apartment">
        <h1 class="w3-text-black">LISTINGS</h1>
        <div class="w3-display-container mySlides0">
        <img src="/images/1_living.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Living Room</p>
        </div>
        </div>
        <div class="w3-display-container mySlides0">
        <img src="/images/1_dining.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Dining Room</p>
        </div>
        </div>
        <div class="w3-display-container mySlides0">
        <img src="/images/1_bedroom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Bedroom</p>
        </div>
        </div>
        <div class="w3-display-container mySlides0">
        <img src="/images/1_bathroom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Bathroom</p>
        </div>
        </div>
    </div>
    <div class="w3-row-padding w3-section">
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/1_living.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(1, 0)" title="Living room">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/1_dining.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(2, 0)" title="Dining room">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/1_bedroom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(3, 0)" title="Bedroom">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/1_bathroom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(4, 0)" title="Bathroom">
        </div>
    </div>

    <div class="w3-container">
        <hr>
        <div class="w3-row w3-large">
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-bath"></i> Bathrooms: <?php echo $baths[0]?></p>
            <p><i class="fa fa-fw fa-bed"></i> Bedrooms: <?php echo $beds[0]?></p>
            <p><i class="fa fa-fw fa-map-marker"></i> Location: <?php echo $city[0]; echo ", "; echo $prov[0]?></p>

        </div>
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-area-chart"></i> Area: <?php echo $sqrFt[0]?>  (square ft) </p>
            <p><i class="fa fa-fw fa-usd"></i> Price: $<?php echo $price[0]?> (CAD)</p>
            <p><i class="fa fa-fw fa-info"></i> Status: <?php echo $stat[0]?></p>
        </div>
    </div>
    <h4><strong>Overview</strong></h4>
        <p> Nestled In Toronto's Exclusive Forest Hill, This 22 Suite Luxury Boutique 
            Condo Offers Both A Large Balcony And Massive Walk-Out Terrace!!! Surrounded 
            By The Lush Greenery Of The Nordheimer Ravine And Only Minutes From Downtown Toronto, 
            This Turnkey Ultra Exclusive 3078 Sq Ft Suite, Is Awaiting The Personal Touch Of Its New 
            Vibrant Owners.</p>
        <hr>
    <hr>

    <!-- listing #2 -->
    <div class="w3-container" id="apartment1">
        <div class="w3-display-container mySlides1">
        <img src="/images/2_frontView.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Facade</p>
        </div>
        </div>
        <div class="w3-display-container mySlides1">
        <img src="/images/2_kitchen.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Kitchen</p>
        </div>
        </div>
        <div class="w3-display-container mySlides1">
        <img src="/images/2_livingRoom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Living Room</p>
        </div>
        </div>
        <div class="w3-display-container mySlides1">
        <img src="/images/2_bathroom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Bathroom</p>
        </div>
        </div>
    </div>
    <div class="w3-row-padding w3-section">
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/2_frontView.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(1, 1)" title="Facade">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/2_kitchen.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(2, 1)" title="Kitchen">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/2_livingRoom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(3, 1)" title="Living Room">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/2_bathroom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(4, 1)" title="Bathroom">
        </div>
    </div>

    <div class="w3-container">
        <hr>
        <div class="w3-row w3-large">
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-bath"></i> Bathrooms: <?php echo $baths[1]?></p>
            <p><i class="fa fa-fw fa-bed"></i> Bedrooms: <?php echo $beds[1]?></p>
            <p><i class="fa fa-fw fa-map-marker"></i> Location: <?php echo $city[1]; echo ", "; echo $prov[1]?></p>
        </div>
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-area-chart"></i> Area <?php echo $sqrFt[1]?> (square ft.)</p>
            <p><i class="fa fa-fw fa-usd"></i> Price: $<?php echo $price[1]?> (CAD)</p>
            <p><i class="fa fa-fw fa-info"></i> Status: <?php echo $stat[1]?></p>
        </div>
        </div>
        <h4><strong>Overview</strong></h4>
        <p> Nestled In Toronto's Exclusive Forest Hill, This 22 Suite Luxury Boutique 
            Condo Offers Both A Large Balcony And Massive Walk-Out Terrace!!! Surrounded 
            By The Lush Greenery Of The Nordheimer Ravine And Only Minutes From Downtown Toronto, 
            This Turnkey Ultra Exclusive 3078 Sq Ft Suite, Is Awaiting The Personal Touch Of Its New 
            Vibrant Owners.</p>
        <hr>
        <hr>

    <!-- listing #3 -->
    <div class="w3-container" id="apartment2">
        <div class="w3-display-container mySlides2">
        <img src="/images/3_frontView.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Facade</p>
        </div>
        </div>
        <div class="w3-display-container mySlides2">
        <img src="/images/3_kitchen.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Kitchen</p>
        </div>
        </div>
        <div class="w3-display-container mySlides2">
        <img src="/images/3_livingRoom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Living Room</p>
        </div>
        </div>
        <div class="w3-display-container mySlides2">
        <img src="/images/3_heritage.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Heritage Building Plaque</p>
        </div>
        </div>
    </div>
    <div class="w3-row-padding w3-section">
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/3_frontView.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(1, 2)" title="Facade">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/3_kitchen.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(2, 2)" title="Kitchen">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/3_livingRoom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(3, 2)" title="Living Room">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/3_heritage.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(4, 2)" title="Heritage Plaque">
        </div>
    </div>

    <div class="w3-container">
        <hr>
        <div class="w3-row w3-large">
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-bath"></i> Bathrooms: <?php echo $baths[2]?></p>
            <p><i class="fa fa-fw fa-bed"></i> Bedrooms: <?php echo $beds[2]?></p>
            <p><i class="fa fa-fw fa-map-marker"></i> Location: <?php echo $city[2]; echo ", "; echo $prov[2]?></p>
        </div>
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-area-chart"></i> Area <?php echo $sqrFt[2]?> (square ft.)</p>
            <p><i class="fa fa-fw fa-usd"></i> Price: $<?php echo $price[2]?> (CAD)</p>
            <p><i class="fa fa-fw fa-info"></i> Status: <?php echo $stat[2]?></p>
        </div>
        </div>
        <h4><strong>Overview</strong></h4>
        <p> Nestled In Toronto's Exclusive Forest Hill, This 22 Suite Luxury Boutique 
            Condo Offers Both A Large Balcony And Massive Walk-Out Terrace!!! Surrounded 
            By The Lush Greenery Of The Nordheimer Ravine And Only Minutes From Downtown Toronto, 
            This Turnkey Ultra Exclusive 3078 Sq Ft Suite, Is Awaiting The Personal Touch Of Its New 
            Vibrant Owners.</p>
        <hr>
    <hr>

    <!-- listing #4 -->
    <div class="w3-container" id="apartment3">
        <div class="w3-display-container mySlides3">
        <img src="/images/4_frontView.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Facade</p>
        </div>
        </div>
        <div class="w3-display-container mySlides3">
        <img src="/images/4_kitchen.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Kitchen</p>
        </div>
        </div>
        <div class="w3-display-container mySlides3">
        <img src="/images/4_livingRoom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Living Room</p>
        </div>
        </div>
        <div class="w3-display-container mySlides3">
        <img src="/images/4_bathroom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Bathroom</p>
        </div>
        </div>
    </div>
    <div class="w3-row-padding w3-section">
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/4_frontView.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(1, 3)" title="Facade">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/4_kitchen.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(2, 3)" title="Kitchen">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/4_livingRoom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(3, 3)" title="Living Room">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/4_bathroom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(4, 3)" title="Bathroom">
        </div>
    </div>

    <div class="w3-container">
        <hr>
        <div class="w3-row w3-large">
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-bath"></i> Bathrooms: <?php echo $baths[3]?></p>
            <p><i class="fa fa-fw fa-bed"></i> Bedrooms: <?php echo $beds[3]?></p>
            <p><i class="fa fa-fw fa-map-marker"></i> Location: <?php echo $city[3]; echo ", "; echo $prov[3]?></p>
        </div>
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-area-chart"></i> Area <?php echo $sqrFt[3]?> (square ft.)</p>
            <p><i class="fa fa-fw fa-usd"></i> Price: $<?php echo $price[3]?> (CAD)</p>
            <p><i class="fa fa-fw fa-info"></i> Status: <?php echo $stat[3]?></p>
        </div>
        </div>
        <h4><strong>Overview</strong></h4>
        <p> Nestled In Toronto's Exclusive Forest Hill, This 22 Suite Luxury Boutique 
            Condo Offers Both A Large Balcony And Massive Walk-Out Terrace!!! Surrounded 
            By The Lush Greenery Of The Nordheimer Ravine And Only Minutes From Downtown Toronto, 
            This Turnkey Ultra Exclusive 3078 Sq Ft Suite, Is Awaiting The Personal Touch Of Its New 
            Vibrant Owners.</p>
        <hr>
    <hr>

        <!-- listing #5 -->
        <div class="w3-container" id="apartment4">
        <div class="w3-display-container mySlides4">
        <img src="/images/5_frontView.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Facade</p>
        </div>
        </div>
        <div class="w3-display-container mySlides4">
        <img src="/images/5_kitchen.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Kitchen</p>
        </div>
        </div>
        <div class="w3-display-container mySlides4">
        <img src="/images/5_livingRoom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Living Room</p>
        </div>
        </div>
        <div class="w3-display-container mySlides4">
        <img src="/images/5_bathroom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Bathroom</p>
        </div>
        </div>
    </div>
    <div class="w3-row-padding w3-section">
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/5_frontView.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(1, 4)" title="Facade">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/5_kitchen.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(2, 4)" title="Kitchen">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/5_livingRoom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(3, 4)" title="Living Room">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/5_bathroom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(4, 4)" title="Bathroom">
        </div>
    </div>

    <div class="w3-container">
        <hr>
        <div class="w3-row w3-large">
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-bath"></i> Bathrooms: <?php echo $baths[4]?></p>
            <p><i class="fa fa-fw fa-bed"></i> Bedrooms: <?php echo $beds[4]?></p>
            <p><i class="fa fa-fw fa-map-marker"></i> Location: <?php echo $city[4]; echo ", "; echo $prov[4]?></p>
        </div>
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-area-chart"></i> Area <?php echo $sqrFt[4]?> (square ft.)</p>
            <p><i class="fa fa-fw fa-usd"></i> Price: $<?php echo $price[4]?> (CAD)</p>
            <p><i class="fa fa-fw fa-info"></i> Status: <?php echo $stat[4]?></p>
        </div>
        </div>
        <h4><strong>Overview</strong></h4>
        <p> Nestled In Toronto's Exclusive Forest Hill, This 22 Suite Luxury Boutique 
            Condo Offers Both A Large Balcony And Massive Walk-Out Terrace!!! Surrounded 
            By The Lush Greenery Of The Nordheimer Ravine And Only Minutes From Downtown Toronto, 
            This Turnkey Ultra Exclusive 3078 Sq Ft Suite, Is Awaiting The Personal Touch Of Its New 
            Vibrant Owners.</p>
        <hr>
    <hr>

        <!-- listing #6 -->
        <div class="w3-container" id="apartment5">
        <div class="w3-display-container mySlides5">
        <img src="/images/6_frontView.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Facade</p>
        </div>
        </div>
        <div class="w3-display-container mySlides5">
        <img src="/images/6_kitchen.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Kitchen</p>
        </div>
        </div>
        <div class="w3-display-container mySlides5">
        <img src="/images/6_livingRoom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Living Room</p>
        </div>
        </div>
        <div class="w3-display-container mySlides5">
        <img src="/images/6_bathroom.jpg" style="width:100%;margin-bottom:-6px">
        <div class="w3-display-bottomleft w3-container w3-black">
            <p>Bathroom</p>
        </div>
        </div>
    </div>
    <div class="w3-row-padding w3-section">
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/6_frontView.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(1, 5)" title="Facade">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/6_kitchen.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(2, 5)" title="Kitchen">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/6_livingRoom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(3, 5)" title="Living Room">
        </div>
        <div class="w3-col s3">
        <img class="demo w3-opacity w3-hover-opacity-off" src="/images/6_bathroom.jpg" style="width:100%;cursor:pointer" onclick="currentDiv(4, 5)" title="Bathroom">
        </div>
    </div>

    <div class="w3-container">
        <hr>
        <div class="w3-row w3-large">
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-bath"></i> Bathrooms: <?php echo $baths[5]?></p>
            <p><i class="fa fa-fw fa-bed"></i> Bedrooms: <?php echo $beds[5]?></p>
            <p><i class="fa fa-fw fa-map-marker"></i> Location: <?php echo $city[5]; echo ", "; echo $prov[5]?></p>
        </div>
        <div class="w3-col s6">
            <p><i class="fa fa-fw fa-area-chart"></i> Area <?php echo $sqrFt[5]?> (square ft.)</p>
            <p><i class="fa fa-fw fa-usd"></i> Price: $<?php echo $price[5]?> (CAD)</p>
            <p><i class="fa fa-fw fa-info"></i> Status: <?php echo $stat[5]?></p>
        </div>
        </div>
        <h4><strong>Overview</strong></h4>
        <p> Nestled In Toronto's Exclusive Forest Hill, This 22 Suite Luxury Boutique 
            Condo Offers Both A Large Balcony And Massive Walk-Out Terrace!!! Surrounded 
            By The Lush Greenery Of The Nordheimer Ravine And Only Minutes From Downtown Toronto, 
            This Turnkey Ultra Exclusive 3078 Sq Ft Suite, Is Awaiting The Personal Touch Of Its New 
            Vibrant Owners.</p>
        <hr>


    <!-- Contact -->
    <div class="w3-container" id="contact">
        <h2>Contact</h2>
        <i class="fa fa-map-marker" style="width:30px"></i> Toronto, CA<br>
        <i class="fa fa-phone" style="width:30px"></i> Phone: +905 151515<br>
        <i class="fa fa-envelope" style="width:30px"> </i> Email: president@platinumBrokers.com<br>
        <p>Questions? Go ahead, ask them:</p>
        <form action="/action_page.php" target="_blank">
        <p><input class="w3-input w3-border" type="text" placeholder="Name" required name="Name"></p>
        <p><input class="w3-input w3-border" type="text" placeholder="Email" required name="Email"></p>
        <p><input class="w3-input w3-border" type="text" placeholder="Message" required name="Message"></p>
        <button type="submit" class="w3-button w3-green w3-third">Send a Message</button>
        </form>
    </div>
    
    <footer class="w3-container w3-padding-16" style="margin-top:32px">Platinum Brokerage. Finding the right home has never been easier. </footer>

    <!-- End page content -->
    </div>

    <!-- Subscribe Modal -->
    <div id="subscribe" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom w3-padding-large">
        <div class="w3-container w3-white w3-center">
        <i onclick="document.getElementById('subscribe').style.display='none'" class="fa fa-remove w3-button w3-xlarge w3-right w3-transparent"></i>
        <h2 class="w3-wide">SUBSCRIBE</h2>
        <p>Join our mailing list to receive updates on available dates and special offers.</p>
        <p><input class="w3-input w3-border" type="text" placeholder="Enter e-mail"></p>
        <button type="button" class="w3-button w3-padding-large w3-green w3-margin-bottom" onclick="document.getElementById('subscribe').style.display='none'">Subscribe</button>
        </div>
    </div>
    </div>

    <script>

        // Slideshow Apartment Images
            var slideIndex = 1;
            var count = 0;
            do{
                showDivs(slideIndex, count);
                count++;
            }while(count < 6);
            

            function currentDiv(n, j) {
                var b = j;
                showDivs(slideIndex = n, b);
            }

            function showDivs(n, b) { 
                var i;
                var x = document.getElementsByClassName('mySlides'+b);
                var dots = document.getElementsByClassName('demo');
                if (n > x.length) {slideIndex = 1}
                if (n < 1) {slideIndex = x.length}
                for (i = 0; i < x.length; i++) {
                    x[i].style.display = "none";
                }
                for (i = 0; i < dots.length; i++) {
                    dots[i].className = dots[i].className.replace(" w3-opacity-off", "");
                }
                x[slideIndex-1].style.display = "block";
                dots[slideIndex-1].className += " w3-opacity-off";
            }

     </script>

    </body>
</html>