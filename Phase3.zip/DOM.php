<?php
 
$dataPoints = array( 
	array("y" => 30, "label" => "Toronto" ),
	array("y" => 25, "label" => "Mississauga" ),
	array("y" => 21, "label" => "Oshawa" ),
	array("y" => 20, "label" => "New Brunswick" ),
	array("y" => 45, "label" => "Vancouver" ),
	array("y" => 14, "label" => "Calagary" )
);
 
?>
<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="homepage.css">
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title:{
		text: "Canadian Real Estate Average DOM (November 2022)"
	},
	axisY: {
		title: "Days On Market (in days)"
	},
	data: [{
		type: "column",
		yValueFormatString: "#,##0.## days",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]

	
});
chart.render();
 
}

</script>
</head>
<body>

<div id="chartContainer" style="height: 470px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<footer>
	<h3 align="center">Contact our agents for further information</h3>
	<button id="myButton" style="color:black" align="center">Contact Agents</button>
</footer>
<script>
	 document.getElementById("myButton").onclick = function () {
            location.href = "ContactPage.html";
        };
</script>
</body>
</html>                       