
<!DOCTYPE html>
<html>
<head>
<style>


th {text-align: left;}
</style>
</head>
<body>



<?php
$country = $_GET['country'];
$province = $_GET['province'];
$city = $_GET['city'];
$price = $_GET['price'];
$area = $_GET['area'];
$bedrooms = $_GET['bedrooms'];
$bathrooms = $_GET['bathrooms'];

$servername = "localhost";
$username = "root";
$password = "";


// Create connection
$con = new mysqli($servername, $username, $password);

// Check connection
if ($con->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

mysqli_select_db($con,"platinumbrokerage");
$sql="SELECT * FROM property WHERE Country ".$country." AND Province ".$province." AND City ".$city." AND Price ".$price." AND Sqr_Ft ".$area." AND Bedrooms ".$bedrooms." AND Bathrooms ".$bathrooms."";
$result = mysqli_query($con,$sql);

echo "<table class=\"table table-striped\">
<tr>
<th>Property ID</th>
<th>Price</th>
<th>Floor Area (sq ft)</th>
<th>City</th>
<th>Province</th>
<th>Country</th>
<th>Zip Code</th>
<th># of Bedrooms</th>
<th># of Bathrooms</th>
</tr>";
while($row = mysqli_fetch_array($result)) {
  echo "<tr scope=\"row\">";
  echo "<td>" . $row['Property_ID'] . "</td>";
  echo "<td>" . $row['Price'] . "</td>";
  echo "<td>" . $row['Sqr_Ft'] . "</td>";
  echo "<td>" . $row['City'] . "</td>";
  echo "<td>" . $row['Province'] . "</td>";
  echo "<td>" . $row['Country'] . "</td>";
  echo "<td>" . $row['Zip_Code'] . "</td>";
  echo "<td>" . $row['Bedrooms'] . "</td>";
  echo "<td>" . $row['Bathrooms'] . "</td>";
  echo "</tr>";
}
echo "</table>";
mysqli_close($con);
?>
</body>
</html> 