 <html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Search - Platinum Brokerage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="propertySearchStyle.css" type="text/css" rel="Stylesheet" />
<script>
function showUser(country, province, city, price, area, bedrooms, bathrooms) {
  if (price == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","findproperty.php?country="+country+"&province="+province+"&city="+city+"&price="+price+"&area="+area+"&bedrooms="+bedrooms+"&bathrooms="+bathrooms,true);
    xmlhttp.send();
  }
}

</script>
</head>
<body>
<header>
    <a id="logo" href="#">Platinum Brokerage</a>
    <nav>
    <ul class="nav_links">
    <li><a href="#">Home</a></li>
    <li><a href="#">Properties</a></li>
    <li><a href="#">Agents</a></li>
    <li><a href="#">Login</a></li>
    <li><a href="#">SignUp</a></li>
    </ul>
    </nav>
    </header>

    <div id="bannerPic" class="container-fluid p-5 bg-primary text-white text-center">
    <div id="bannerTitle">FIND PROPERTIES</div>
    </div>

<div class="container-fluid" id="searchForm">
<form class="row g-3">
  <div class="form-group col-md-12">
  <label for="country">Country</label>
  <select class="form-control" name="country" onchange="showUser(country.value, province.value, city.value, price.value, area.value, bedrooms.value, bathrooms.value)">
  <option value="= Country" selected="true">All</option>
  <option value="= 'Canada'">Canada</option>
  <option value="= 'United States'">United States</option>
  </select>
  </div>

  <div class="form-group col-md-6">
  <label for="province">Province</label>
  <select class="form-control" name="province" onchange="showUser(country.value, province.value, city.value, price.value, area.value, bedrooms.value, bathrooms.value)">
  <option value="= Province" selected="true">All</option>
  <option value="= 'Ontario'">Ontario</option>
  <option value="= 'Quebec'">Quebec</option>
  <option value="= 'Nova Scotia'">Nova Scotia</option>
  <option value="= 'New Brunswick'">New Brunswick</option>
  <option value="= 'Manitoba'">Manitoba</option>
  <option value="= 'British Columbia'">British Columbia</option>
  <option value="= 'Prince Edward Island'">Prince Edward Island</option>
  <option value="= 'Saskatchewan'">Saskatchewan</option>
  <option value="= 'Alberta'">Alberta</option>
  <option value="= 'Newfoundland and Labrador'">Newfoundland and Labrador</option>
  </select>
  </div>

  <div class="form-group col-md-6">
  <label for="city">City</label>
  <select class="form-control" name="city" onchange="showUser(country.value, province.value, city.value, price.value, area.value, bedrooms.value, bathrooms.value)">
  <option value="= City" selected="true">All</option>
  <option value="= 'Toronto'">Toronto</option>
  <option value="= 'Oshawa'">Oshawa</option>
  <option value="= 'Calgary'">Calgary</option>
  <option value="= 'Vancouver'">Vancouver</option>
  <option value="= 'Mississauga'">Mississauga</option>
  <option value="= 'Oshawa'">Oshawa</option>
  </select>
  </div>

  <div class="form-group col-md-6">
  <label for="price">Price Range</label>
  <select class="form-control" name="price" onchange="showUser(country.value, province.value, city.value, price.value, area.value, bedrooms.value, bathrooms.value)">
  <option value="= Price" selected="true">All</option>
  <option value="< 300000">Less than $300,000</option>
  <option value="BETWEEN 300000 AND 500000">Between $300,000 and $500,000</option>
  <option value="> 500000">Greater than $500,000</option>
  </select>
  </div>

  <div class="form-group col-md-6">
  <label for="area">Floor Area (sq ft)</label>
  <select class="form-control" name="area" onchange="showUser(country.value, province.value, city.value, price.value, area.value, bedrooms.value, bathrooms.value)">
  <option value="= Sqr_Ft" selected="true">All</option>
  <option value="< 1000">Less than 1000 sqft</option>
  <option value="BETWEEN 1000 AND 1500">Between 1000 and 1500 sqft</option>
  <option value="> 1500">Greater than 1500 sqft</option>
  </select>
  </div>

  <div class="form-group col-md-6">
  <label for="bedrooms"># of bedrooms</label>
  <select class="form-control" name="bedrooms" onchange="showUser(country.value, province.value, city.value, price.value, area.value, bedrooms.value, bathrooms.value)">
  <option value="= Bedrooms" selected="true">All</option>
  <option value="< 3">Less than 3</option>
  <option value="BETWEEN 3 AND 6">Between 3 and 6</option>
  <option value="> 6">Greater than 6</option>
  </select>
  </div>

  <div class="form-group col-md-6">
  <label for="bathrooms"># of bathrooms</label>
  <select class="form-control" name="bathrooms" onchange="showUser(country.value, province.value, city.value, price.value, area.value, bedrooms.value, bathrooms.value)">
  <option value="= Bathrooms" selected="true">All</option>
  <option value="< 3">Less than 3</option>
  <option value="BETWEEN 3 AND 6">Between 3 and 6</option>
  <option value="> 6">Greater than 6</option>
  </select>
  </div>

</form>
</div>
<br>
<div id="txtHint"><p style="text-align:center">Search results will be displayed here.</p></div>

</body>
</html> 