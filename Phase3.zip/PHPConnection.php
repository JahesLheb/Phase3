<?php
if(!empty($_POST)) {

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "platinumbrokerage";



    //Database connection 
    $conn = mysqli_connect($servername, $username, $password, $dbname); 
    if (!$conn){
        die("Connection Failed: ".mysqli_connect_error());
    }


$sql = "INSERT INTO contact (name, email, message) VALUES 
('{$conn->real_escape_string($_POST['test'])}', '{$conn->real_escape_string($_POST['email'])}',
'{$conn->real_escape_string($_POST['message'])}')";


$insert = $conn->query($sql);

if($insert == TRUE){
    if (empty($_POST['test'])){
        header("Refresh: 0; url=ContactForm.html");
        echo "<script>alert('Please input all your details.')</script>";
    }elseif (empty($_POST['email'])){
        header("Refresh: 0; url=ContactForm.html");
        echo "<script>alert('Please input all your details.')</script>";
    }elseif (empty($_POST['message'])){
        header("Refresh: 0; url=ContactForm.html");
        echo "<script>alert('Please input all your details.')</script>";
    }elseif (isset($_POST['test'], $_POST['email'], $_POST['message'])) {
    function function_alert($name){
        header("Refresh: 0; url=ContactForm.html");
        echo "<script>alert('Thank you for contacting us $name, our agent will get back to you shortly.')</script>";
        die;
    }
    function_alert($_POST['test']);
    }
}
else {
    die("Error: {$conn->errno} : {$conn->error}");
    exit();
}
}

