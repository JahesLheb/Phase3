<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="signup.css" type="text/css" rel="Stylesheet" />
	<title>Login</title>
</head>
<body>

	
	<h1 style="text-align: center;">Login</h2>
		<p>Please enter valid credentials to login.</p>

	<form action="login.inc.php" method="post">
		<label><b>Username/Email</b></label>
		<input type="text" name="uid" placeholder="Username/Email..">
		<br>
		<label><b>Password</b></label>
		<input type="password" name="pwd" placeholder="Password..">
		

		<button type="submit" name="submit">Login </button>
		
	</form>

	<?php

		if(isset($_GET["error"])){
			if($_GET["error"] == "emptyinput"){
				echo "<p>Fill in all fields ! </p>";
			}

			else if($_GET["error"] == "wronglogin"){
				echo "<p>Incorrect Login information!</p>";
			}

		}
	?>



</body>
</html>