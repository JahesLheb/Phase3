<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "platinumbrokerage";
$connection = mysqli_connect ($dbhost, $dbuser, $dbpass, $dbname); // Connects to Database

// Checks for errors
if (mysqli_connect_errno())
{
    die ("Database connection failed: ".mysqli_connect_error()."(".mysqli_connect_errno().") ");
}

// Get Input
$location = strval($_GET['location']);    // A
$name = strval($_GET['name']);            // B
$specialty = strval($_GET['specialty']);  // C
$language = strval($_GET['language']);    // D
$office = strval($_GET['office']);        // E

//------------------------------------------------------------
// PRODUCES RESULT DEPENDING ON THE GIVEN INPUT
//------------------------------------------------------------

// ABCDE
if($name != "" && $location != "" && $specialty != "" && $language != "Choose..." && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// ABCD
elseif($name != "" && $location != "" && $specialty != "" && $language != "Choose...")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// ABCE
elseif($name != "" && $location != "" && $specialty != "" && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// ABDE
elseif($name != "" && $location != "" && $language != "Choose..." && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    ");
}
// ACDE
elseif($name != "" && $specialty != "" && $language != "Choose..." && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// BCDE
elseif($location != "" && $specialty != "" && $language != "Choose..." && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// ABC
elseif($name != "" && $location != "" && $specialty != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// ABD
elseif($name != "" && $location != "" && $language != "Choose...")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    ");
}
// ABE
elseif($name != "" && $location != "" && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    ");
}
// ACD
elseif($name != "" && $specialty != "" && $language != "Choose...")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// ACE
elseif($name != "" && $specialty != "" && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// ADE
elseif($name != "" && $language != "Choose..." && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    ");
}
// BCD
elseif($location != "" && $specialty != "" && $language != "Choose...")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// BCE
elseif($location != "" && $specialty != "" && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// BDE
elseif($location != "" && $language != "Choose..." && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    ");
}
// CDE
elseif($specialty != "" && $language != "Choose..." && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// AB
elseif($name != "" && $location != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    ");
}
// AC
elseif($name != "" && $specialty != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// AD
elseif($name != "" && $language != "Choose...")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    ");
}
// AE
elseif($name != "" && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    ");
}
// BC
elseif($location != "" && $specialty != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// BD
elseif($location != "" && $language != "Choose...")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    ");
}
// BE
elseif($location != "" && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    ");
}
// CD
elseif($specialty != "" && $language != "Choose...")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// CE
elseif($specialty != "" && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    AND Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// DE
elseif($language != "Choose..." && $office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    AND Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    ");
}
// A
elseif($name != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Name LIKE '%$name%'
    ");
}
// B
elseif($location != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM location Where location = '$location')
    ");
}
// C
elseif($specialty != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM special Where specialty = '$specialty')
    ");
}
// D
elseif($language != "Choose...")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM language Where language = '$language')
    ");
}
// E
elseif($office != "")
{
    $result = mysqli_query($connection,"SELECT * FROM realtor WHERE Realtor_ID IN (SELECT realtor_id FROM brokerage Where name LIKE '%$office%')
    ");
}
// If No Inputs, Should Not Be Used
else
{
    $result = mysqli_query($connection,"SELECT * FROM realtor");
}

// Create Output
$output = "<table class='table'><thead><tr><th scope='col'>Name</th><th scope='col'>Phone Number</th><th scope='col'>Email</th></tr></thead>";
$output .= "<tbody>";
while($row = mysqli_fetch_array($result))
{
    $output .= "<tr>";
    $output .= "<td>".$row['Name']."</td>";
    $output .= "<td>".$row['Phone_No']."</td>";
    $output .= "<td>".$row['Email']."</td>";
    $output .= "</tr>";
}
$output .= "</tbody></table>";

// Returns Result To Caller
echo $output;

// Close Connection
$connection->close();
?>