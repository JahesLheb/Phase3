<?php
    $hs = "localhost";
    $us = "root";
    $ps = "";

    $conn = mysqli_connect("$hs", "$us", "$ps", "platinumbrokerage");

    if($conn === false){
        die("MySQL could not connect...");
    }
?>