<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "platinumbrokerage";
$connection = mysqli_connect ($dbhost, $dbuser, $dbpass, $dbname); //Connects to database

//Checks for errors
if (mysqli_connect_errno())
{
    die ("Database connection failed: ".mysqli_connect_error()."(".mysqli_connect_errno().") ");
}
else
{
  debug_to_console("Connected to database");
}

// Meetings, how to know if client or realtor?
$result = mysqli_query($connection,"SELECT schedule.Time, schedule.Date, realtor.Name as 'rn', client.Name as 'cn', property.City, property.Province, property.Country, property.Zip_Code
FROM schedule, realtor, client, property
WHERE schedule.Realtor_ID = 1 AND schedule.Realtor_ID = realtor.Realtor_ID AND client.Customer_ID = schedule.Customer_ID AND property.Property_ID = schedule.Property_ID");
$output = "<table class='table table-hover table-primary'><thead><tr><th scope='col'>Realor Name</th><th scope='col'>Date</th><th scope='col'>Time</th><th scope='col'>City</th><th scope='col'>Province</th><th scope='col'>Country</th><th scope='col'>Postal Code</th></tr></thead><tbody>";
while($row = mysqli_fetch_array($result))
{
    $output .= "<tr>";
    $output .= "<td>".$row['rn']."</td>";
    $output .= "<td>".$row['Date']."</td>";
    $output .= "<td>".$row['Time']."</td>";
    $output .= "<td>".$row['City']."</td>";
    $output .= "<td>".$row['Province']."</td>";
    $output .= "<td>".$row['Country']."</td>";
    $output .= "<td>".$row['Zip_Code']."</td>";
    $output .= "</tr>";

    debug_to_console($row['Time']);
    debug_to_console($row['Date']);
    debug_to_console($row['rn']);
    debug_to_console($row['cn']);
    debug_to_console($row['City']);
    debug_to_console($row['Province']);
    debug_to_console($row['Country']);
    debug_to_console($row['Zip_Code']);
}
$output .= "</tbody><table>";

// Contracts

//Used to log to console
function debug_to_console($data) {
  $output = $data;
  if (is_array($output))
      $output = implode(',', $output);

  echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}

//Closes connection
$connection->close();
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Required for Bootstrap5 -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="styleDash.css">
</head>

<body>
  <!-- Bootstrap Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="homepage.html">Home</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="login.php">Logout</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="searchRealtor.php">Search Realtor</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#">Action</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
          </li> -->
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </nav>

  <!-- Banner -->
  <div id="bannerPic" class="container-fluid p-5 bg-primary text-white text-center">
    <div id="bannerTitle">Welcome</div>
  </div>

  <div id="schedule">
    <h1 id="title">Your Meetings</h1>
    <a><?php echo $output; ?></a>
  </div>

  <div id="contract">
    <h1 id="title">Your Contracts</h1>
  </div>
</body>
</html>