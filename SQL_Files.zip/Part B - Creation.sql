create database platinumBrokerage;
use platinumBrokerage;
CREATE TABLE Property (
	Property_ID INT NOT NULL AUTO_INCREMENT,
    Price float,
    Sqr_Ft float,
    City varchar(255),
    Province varchar(255),
    Country varchar(255),
    Zip_Code varchar(255),
    Bedrooms int,
    Bathrooms int,
    Primary key (Property_ID)
);
CREATE TABLE Listing (
	Listing_ID INT NOT NULL AUTO_INCREMENT,
    Property_ID INT NOT NULL,
    Status VARCHAR(255) ,
    Date  date NOT NULL,
    DOM int NOT NULL,
    Selling_Date date ,
    PRIMARY KEY (Listing_ID),
    foreign key (Property_ID) references Property(Property_ID) on delete cascade
);

CREATE TABLE Realtor (
	Realtor_ID INT NOT NULL AUTO_INCREMENT,
    Name varchar(255),
    Phone_No bigint NOT NULL,
    Joining_Date  date NOT NULL,
    Email varchar(255) NOT NULL,
    PRIMARY KEY (Realtor_ID)
);

CREATE TABLE Client (
	Customer_ID INT NOT NULL AUTO_INCREMENT,
    Name varchar(255) NOT NULL,
    Phone_No bigint NOT NULL,
    Email varchar(255) NOT NULL,
    Annual_Income float NOT NULL,
    PRIMARY KEY (Customer_ID)
);

CREATE TABLE Managed (
	Realtor_ID INT NOT NULL,
	Property_ID INT NOT NULL,
	CONSTRAINT PK_Managed primary key (Realtor_ID,Property_ID),
	FOREIGN KEY (Realtor_ID) REFERENCES Realtor(Realtor_ID) ON DELETE CASCADE,
	FOREIGN KEY (Property_ID) REFERENCES Property(Property_ID) ON DELETE CASCADE
);

CREATE TABLE AssignedTo (
	Realtor_ID INT NOT NULL,
	Customer_ID INT NOT NULL,
	CONSTRAINT PK_Managed primary key (Realtor_ID, Customer_ID),
	FOREIGN KEY (Realtor_ID) REFERENCES Realtor(Realtor_ID) ON DELETE CASCADE,
	FOREIGN KEY (Customer_ID) REFERENCES Client(Customer_ID) ON DELETE CASCADE
);

CREATE TABLE Schedule(
	Realtor_ID INT NOT NULL,
	Customer_ID INT NOT NULL,
    Property_ID INT NOT NULL,
    Date date,
    Time time,
	CONSTRAINT PK_Scheduled primary key (Property_ID, Date, Time),
	FOREIGN KEY (Realtor_ID) REFERENCES Realtor(Realtor_ID) ON DELETE CASCADE,
	FOREIGN KEY (Customer_ID) REFERENCES Client(Customer_ID) ON DELETE CASCADE,
    FOREIGN KEY (Property_ID) REFERENCES Property(Property_ID) ON DELETE CASCADE
); 

CREATE TABLE Contracts (
	ContractID int NOT NULL,
    Customer_ID int not null,
    Realtor_ID int not null,
    NumberOfPayments int,
    NumberofInstallments int,
    Total_Payment float,
    Installment_Amt float,
    DateSigned date,
    PRIMARY KEY (ContractID),
    FOREIGN KEY (Realtor_ID) REFERENCES Realtor(Realtor_ID) ON DELETE CASCADE,
	FOREIGN KEY (Customer_ID) REFERENCES Client(Customer_ID) ON DELETE CASCADE
);

CREATE TABLE Installment (
	InvoiceID INT NOT NULL,
    ContractID int NOT NULL,
    Amount float,
    Date_Created date,
    Date_Paid date,
    PRIMARY KEY(InvoiceID),
    FOREIGN KEY (ContractID) REFERENCES Contracts(ContractID) ON DELETE CASCADE
);

CREATE TABLE Login (
	Banner_ID varchar(255) NOT NULL,
    Password varchar(255) NOT NULL,
    Customer_ID int not null,
    Realtor_ID int not null,
    PRIMARY KEY (Banner_ID),
    FOREIGN KEY (Realtor_ID) REFERENCES Realtor(Realtor_ID) ON DELETE CASCADE,
	FOREIGN KEY (Customer_ID) REFERENCES Client(Customer_ID) ON DELETE CASCADE
);

CREATE TABLE contact (
	name varchar(255) ,
    email varchar(255),
    message varchar(255)
);

CREATE TABLE signup (
	User_ID int(11) NOT NULL auto_increment,
    Username varchar(255),
    Email varchar(255),
    UID varchar(255),
    PWD varchar(255),
    Role varchar(255),
    PRIMARY KEY (User_ID)
);


    
