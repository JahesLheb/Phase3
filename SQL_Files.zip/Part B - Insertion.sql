use platinumBrokerage;

Insert into Client (Name, Phone_No, Email, Annual_Income)
values('Soumil Thete', 6478556993, 'sthete@hotmail.com', 920000), 
	  ('Sehaj Behl', 9028536913, 'sehajbehl@hotmail.com', 637001),
      ('Vishan Patel', 6479456771, 'vpatel@hotmail.com', 456045),
      ('Nagahiro Aoyama', 9021234993, 'nagahiro@gmail.com', 833000),
      ('Angad Singh', 6475384765, 'angadsingh@gmail.com', 700000),
      ('Jason Stathom', 9027894865, 'jstathom@rediffmail.com', 300000);
      
Insert into Realtor (Name, Phone_No, Email, Joining_Date)
values('Jackson Smith', 6472345728, 'jsmith@gmail.com', '1998-01-31'), 
	  ('Edgar Husain', 9026498521, 'ehusain@hotmail.com', '1999-12-10'),
      ('Damon Wade', 6477479635, 'wadedamon@hotmail.com', '2000-05-12'),
      ('Rajnathan Muthuswami', 9028967452, 'muthu@gmail.com', '1989-04-30'),
      ('Qi Chan', 6478527536, 'qichan@gmail.com', '2000-07-27'),
      ('Abiona Abara', 9028967532, 'abiabara@rediffmail.com', '1997-02-28');
      
INSERT INTO contracts  (ContractID,Customer_ID,Realtor_ID,NumberofPayments,NumberofInstallments,Total_Payment,Installment_Amt,DateSigned)
VALUES	(2000,1,6,4,4,200000,50000,'2021-01-15'),
		(2002,2,5,2,2,150000,75000,'2022-09-29'),
		(2004,3,4,8,8,225000,28125,'2019-08-21'),
        (2006,4,3,12,12,450000,37500,'2022-09-29'),
        (2008,5,2,16,16,875000,54687.5,'2018-07-12'),
        (2010,6,1,20,20,950000,47500,'2017-11-15');
        
INSERT INTO installment (InvoiceID,ContractID,Amount,Date_Created,Date_Paid)
VALUES	(4002,2000,50000,'2021-01-25','2021-02-01'),
		(4004,2002,75000,'2022-09-15','2022-09-30'),
        (4006,2004,28125,'2019-09-01','2019-09-30'),
        (4008,2006,37500,'2022-07-22','2022-07-27'),
        (4010,2008,54687.5,'2018-07-21','2018-07-28'),
        (4012,2010,47500,'2017-11-05','2017-11-28');
        
insert into managed (Realtor_ID,Property_ID) 
values	(3,1),
		(2,5),
        (4,2),
        (1,6),
        (5,3),
        (6,4);
        
insert into schedule (Realtor_ID,Customer_ID,Property_ID,Date,Time)
values	(6,1,1,'2022-11-15','10:30:00'),
		(5,2,3,'2022-11-12','13:00:00'),
        (4,3,2,'2022-12-01','18:30:00'),
        (3,4,1,'2022-11-25','15:35:00'),
        (2,5,5,'2022-12-10','17:00:00'),
        (1,6,6,'2022-12-05','11:30:00');
        
Insert into Property (Price, Sqr_Ft, City, Province,Country,Zip_Code, Bedrooms, Bathrooms)
values(450000, 700, 'Toronto', 'Ontario','Canada','M1ROE9', 3, 3), 
	  (225000, 850, 'Oshawa', 'Ontario','Canada','L1G3Z2', 4, 2),
      (375000, 675, 'Calgary', 'Alberta','Canada','CL2340', 5, 3),
      (525010, 550, 'Vancouver', 'British Columbia','Canada','V1G3K2', 6, 5),
      (895780, 1020, 'Fredericton', 'New Brunswick','Canada','E3A0A4', 10, 7),
      (525000, 1550, 'Mississauga', 'Ontario','Canada','L4T0A1', 7, 5);
      
select * from property;
      
INSERT INTO Listing(Listing_ID, Property_ID, Date, Status, DOM, Selling_Date) 
VALUES	(1003, 1,'2018-03-15','Sold', 30,'2018-04-15'),
		(1004, 6,'2019-05-16','Sold', 25,'2019-06-11'),
		(1005, 2,'2022-11-01','Active', 21, NULL),
		(1001, 5,'2022-09-20','Active', 20, NULL),
		(1006, 4,'2022-02-02','Sold', 45,'2022-11-02'),
		(1002, 3,'2021-11-13','Pending', 14,NULL);

INSERT INTO AssignedTo (Realtor_ID, Customer_ID) 
VALUES (1,6),
	   (2,5),
       (3,4),
       (4,3),
       (5,2),
	   (6,1);
       
INSERT INTO Login (Banner_ID, Password, Customer_ID, Realtor_ID)
values	('sthete', '********', 1, 0),
		('sbehl', '********', 2, 0),
        ('vpatel', '********', 3, 0),
        ('nhiro', '********', 4, 0),
        ('asingh', '********', 5, 0),
        ('jstathom', '********', 6, 0),
        ('jsmith', '********', 0, 1),
        ('ehusain', '********', 0, 2),
        ('dwade', '********', 0, 3),
        ('rmuthuswami', '********', 0, 4),
        ('qchan', '********', 0, 5),
        ('aabara', '********', 0, 6);


        
