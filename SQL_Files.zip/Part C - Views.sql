/* View 1. Displays all schedules (meetings) sorted by date.
Displays client/realtor name, date/time, and location. */
CREATE OR REPLACE VIEW View1 AS
SELECT client.Name as 'Customer Name', realtor.Name as 'Realtor Name', 
	schedule.date as 'Date', schedule.time as 'Time', property.Country, property.Province, property.City, property.Zip_code
FROM client, realtor, schedule, property
WHERE schedule.Realtor_ID = realtor.Realtor_ID AND schedule.Customer_ID = client.Customer_ID AND schedule.Property_ID = property.Property_ID
ORDER BY schedule.date;

/* View 2. Displays all properties with at least one associated listing
that is active and has been on the market for more than 15 days. Results are grouped by province. */
CREATE OR REPLACE VIEW View2 AS
SELECT property.Province, property.Property_ID
FROM property
WHERE property.Property_ID = ANY (
	SELECT listing.Property_ID 
	FROM listing 
	WHERE listing.DOM > 15 AND listing.Status = 'Active')
GROUP BY property.Province;

/* View 3. Displays all realtors that have never had a contract with a total payment greater than 200000 */
CREATE OR REPLACE VIEW View3 AS
SELECT realtor.Name
FROM realtor
WHERE NOT EXISTS (
	SELECT contracts.Realtor_ID 
    FROM contracts 
    WHERE realtor.Realtor_ID = contracts.Realtor_ID AND contracts.Total_Payment > 200000);
    
    
/* View 4. Since FULL JOIN is not supported by MySQL, LEFT JOIN and RIGHT JOIN are used to emulate a FULL JOIN.
Returns all customers with either only their annual income (if no contracts exist), 
only the total payment for the contracts they have (if annual income is not provided), or both. */
CREATE OR REPLACE VIEW View4 AS
SELECT client.Name, client.Annual_Income, contracts.Total_Payment
FROM client
LEFT JOIN contracts ON client.Customer_ID = contracts.Customer_ID
UNION ALL
SELECT client.Name, client.Annual_Income, contracts.Total_Payment
FROM client
RIGHT JOIN contracts ON client.Customer_ID = contracts.Customer_ID
WHERE client.Customer_ID IS NULL;

/* View 5. Displays all properties that either are priced below the average property price in Canada, 
or have more than 1000 square feet in floor area while remaining under 600000 price. */
CREATE OR REPLACE VIEW View5 AS
SELECT p1.Property_ID, p1.Province, p1.Price, p1.Sqr_Ft
FROM property as p1
WHERE p1.Price < (
	SELECT AVG(Price) 
    FROM property as p2 
    WHERE p2.Country = 'Canada')
UNION
	SELECT p3.Property_ID, p3.Province, p3.Price, p3.Sqr_Ft
	FROM property as p3
	WHERE p3.Sqr_Ft > 1000 AND p3.Price < 600000;

/* View 6. Displays the number of customers each realtor is responsible for. */
CREATE OR REPLACE VIEW View6 AS
SELECT assignedto.Realtor_ID, COUNT(assignedto.Customer_ID)
FROM assignedto
GROUP BY assignedto.Customer_ID;

/* View 7. Displays the names of realtors and the customers they are responsible for. */
CREATE OR REPLACE VIEW View7 AS
SELECT realtor.Name as 'Realtor', client.Name as 'Customer'
FROM realtor, client, assignedto
WHERE realtor.Realtor_ID = assignedto.Realtor_ID AND client.Customer_ID = assignedto.Customer_ID;

/* View 8. Displays the names of all realtors, property ID of the properties they manage, 
associated listing IDs, their status, and listing date. */
CREATE OR REPLACE VIEW View8 AS
SELECT realtor.Name, managed.Property_ID, listing.Listing_ID, listing.Status, listing.Date
FROM listing, managed, realtor
WHERE realtor.Realtor_ID = managed.Realtor_ID AND listing.Property_ID = managed.Property_ID
ORDER BY realtor.Name, listing.Date;

/* View 9. Displays all properties that have at least one active listing. */
CREATE OR REPLACE VIEW View9 AS
SELECT *
FROM property
WHERE property.Property_ID = ANY (
	SELECT listing.Property_ID 
    FROM listing
    WHERE listing.Status = 'Active');
    
/* View 10. Displays all signed contracts, including customer name, realtor name, and the date signed. */
CREATE OR REPLACE VIEW View10 AS
SELECT contracts.ContractID, realtor.Name as 'Realtor', client.Name as 'Customer', contracts.DateSigned
FROM realtor, client, contracts
WHERE realtor.Realtor_ID = contracts.Realtor_ID AND client.Customer_ID = contracts.Customer_ID AND contracts.DateSigned IS NOT NULL;
